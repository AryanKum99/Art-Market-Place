var superfish = $('#st-navbar-desktop-menu-nav').superfish({
    //add options here if required
});